"""
Reads WhatsApp-submitted issue reports for the admin dashboard.

ANONYMIZED ON THE WAY OUT, same philosophy as complaints.py: employee_id is
never returned from this module, and `created_at` is truncated to a date.
The full-detail rows (with employee_id and exact timestamp) still exist in
`issue_reports` for the WhatsApp-side workflow (a worker's own report
history, duplicate-submission checks) — this module is deliberately the
only thing standing between that table and the admin UI.

Reads the SQLite file directly with the stdlib (no SQLAlchemy dependency
here) so this module doesn't require importing the whatsapp/ package or its
requirements into the Streamlit process.
"""
from __future__ import annotations

import sqlite3
from pathlib import Path

import pandas as pd

_DB_PATH = Path(__file__).resolve().parent.parent / "project" / "stationshield_whatsapp.db"

COLUMNS = [
    "report_code", "station_id", "station_name", "category",
    "severity", "description", "status", "source", "reported_on",
]


def _connect() -> sqlite3.Connection | None:
    if not _DB_PATH.exists():
        return None
    return sqlite3.connect(f"file:{_DB_PATH}?mode=ro", uri=True)


def load_reports() -> pd.DataFrame:
    """All WhatsApp/dashboard issue reports, anonymized. Returns an empty
    (but correctly-columned) frame if the database or table doesn't exist
    yet, so the dashboard never crashes on a fresh checkout."""
    conn = _connect()
    if conn is None:
        return pd.DataFrame(columns=COLUMNS)

    try:
        frame = pd.read_sql_query(
            "SELECT report_code, station_id, station_name, category, severity, "
            "description, status, source, created_at FROM issue_reports "
            "ORDER BY created_at DESC",
            conn,
        )
    except (pd.errors.DatabaseError, sqlite3.OperationalError):
        # Table doesn't exist yet (no reports submitted, or older DB file).
        return pd.DataFrame(columns=COLUMNS)
    finally:
        conn.close()

    if frame.empty:
        frame["reported_on"] = []
        return frame[COLUMNS]

    # Anonymization: date only, no employee_id column ever selected above.
    frame["reported_on"] = pd.to_datetime(frame["created_at"]).dt.date.astype(str)
    return frame[COLUMNS]


def filtered(
    frame: pd.DataFrame,
    station: str | None = None,
    category: str | None = None,
    severity: str | None = None,
    status: str | None = None,
) -> pd.DataFrame:
    out = frame
    if station and station != "All stations":
        out = out[out["station_name"] == station]
    if category and category != "All categories":
        out = out[out["category"] == category]
    if severity and severity != "All severities":
        out = out[out["severity"] == severity]
    if status and status != "All statuses":
        out = out[out["status"] == status]
    return out
