"""
Minimal admin gate for the Streamlit dashboard.

Not real authentication — one shared password from an environment variable,
checked client-session-side. Good enough to keep a hackathon demo from being
wide open at a shared link; not a substitute for per-admin accounts, audit
logging of who viewed what, or anything you'd want in production. Document
this limitation in the README rather than letting it read as more than it is.
"""
from __future__ import annotations

import os

import streamlit as st

ADMIN_PASSWORD_ENV_VAR = "ADMIN_DASHBOARD_PASSWORD"


def require_admin_password() -> bool:
    """Renders a password gate if needed. Returns True once the correct
    password has been entered (or if no password is configured at all, in
    which case it warns and lets the dashboard through — better to fail
    open with a visible warning here than silently lock out a local demo
    when someone hasn't set the env var yet)."""
    expected = os.environ.get(ADMIN_PASSWORD_ENV_VAR)

    if not expected:
        st.warning(
            f"{ADMIN_PASSWORD_ENV_VAR} is not set — the dashboard is running with NO password "
            "gate. Set this environment variable before sharing this link with anyone.",
            icon="⚠️",
        )
        return True

    if st.session_state.get("admin_authed"):
        return True

    st.title("StationShield — Admin sign-in")
    password = st.text_input("Admin password", type="password")
    if st.button("Sign in"):
        if password == expected:
            st.session_state["admin_authed"] = True
            st.rerun()
        else:
            st.error("Incorrect password.")
    return False
