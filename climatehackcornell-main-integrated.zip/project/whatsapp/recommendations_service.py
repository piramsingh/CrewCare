"""
Single-station environmental recommendation, built from the *same* model
functions admin_dashboard_model/app.py already uses for the map (see its
`score_borough()`). Nothing here reimplements the physics — it just calls
into the existing modules for one station instead of scoring all 496.

admin_dashboard_model isn't a Python package (its files do flat imports like
`import risk`), so it's added to sys.path once at import time rather than
imported as a package. This mirrors how Streamlit already runs it.
"""
from __future__ import annotations

import sys
from pathlib import Path

_DASHBOARD_DIR = Path(__file__).resolve().parent.parent.parent / "admin_dashboard_model"
if str(_DASHBOARD_DIR) not in sys.path:
    sys.path.insert(0, str(_DASHBOARD_DIR))

import flood          # noqa: E402
import indoor          # noqa: E402
import openmeteo as om  # noqa: E402
import risk as risk_model  # noqa: E402
import thermal          # noqa: E402


class RecommendationUnavailable(Exception):
    pass


def get_station_recommendation(station_id: str) -> dict:
    """Returns a plain dict (not a pandas row) so conversation_service.py
    doesn't need a pandas dependency of its own. Raises
    RecommendationUnavailable if the station isn't in the spine or live data
    can't be fetched — callers must show 'data unavailable', never invent
    values (per the spec's prohibition on fabricated sensor data)."""
    stations = om.load_stations()
    matches = stations[stations["gtfs_stop_id"] == station_id]
    if matches.empty:
        raise RecommendationUnavailable(f"Unknown station_id '{station_id}'.")
    station = matches.iloc[0]

    try:
        snapshot = om.fetch_snapshot(stations, ttl_hours=3.0, force=False)
        values = om.station_current(snapshot, station)
    except Exception as exc:  # network/API failure — degrade honestly, don't fabricate
        raise RecommendationUnavailable(f"Could not fetch live conditions: {exc}") from exc

    if values.get("temperature_2m") is None:
        raise RecommendationUnavailable("Live conditions unavailable for this station right now.")

    source = indoor.subway_delta_c(station)
    climate = thermal.station_climate(
        station,
        t_out_f=values.get("temperature_2m"),
        rh_out=values.get("relative_humidity_2m"),
        dewpoint_out_f=values.get("dew_point_2m"),
        pressure_hpa=values.get("surface_pressure"),
        daily_means_f=om.station_daily_means(snapshot, station),
    )
    platform_pm25 = indoor.platform_pm25(values.get(indoor.PM25_KEY), source.delta_c)
    flood_climate = flood.station_flood_climate(
        om.station_precipitation_series(snapshot, station),
        om.station_flood_series(snapshot, station),
        rh_in=climate.rh_in,
        enclosed=indoor.enclosure_for(station["structure"]).is_enclosed(),
    )
    assessed = risk_model.station_risk(
        platform_pm25, climate.heat_index_in_f,
        flood_climate.mold.level, flood_climate.mold.description,
    )

    return {
        "station_id": station_id,
        "station_name": station["stop_name"],
        "level": assessed.level,
        "level_name": assessed.name,
        "driver": assessed.driver,
        "pm25": round(platform_pm25, 1) if platform_pm25 is not None else None,
        "temp_f": round(climate.t_in_f, 1),
        "heat_index_f": round(climate.heat_index_in_f, 1),
        "rh": round(climate.rh_in),
        "mould_level": flood_climate.mold.level,
        "mould_why": flood_climate.mold.description,
    }


def format_recommendation_message(rec: dict) -> str:
    return (
        f"Today's station safety summary — {rec['station_name']}:\n\n"
        f"Overall concern: {rec['level_name']} (driven by {rec['driver']})\n"
        f"Platform PM2.5: {rec['pm25']} ug/m3 (modelled, not measured)\n"
        f"Feels-like temperature: {rec['heat_index_f']} F\n"
        f"Relative humidity: {rec['rh']}%\n"
        f"Mould risk: {rec['mould_level']} — {rec['mould_why']}\n\n"
        "This is a modelled planning estimate, not a measurement and not a "
        "medical diagnosis. If you have symptoms or health concerns, contact "
        "your supervisor or occupational health team.\n\n"
        "Reply MENU for options."
    )


def format_unavailable_message(station_name: str | None) -> str:
    label = station_name or "your station"
    return (
        f"Today's station safety summary for {label}: data unavailable right now — "
        "we couldn't fetch current conditions. Please try again shortly, or contact "
        "your supervisor if conditions seem unsafe.\n\nReply MENU for options."
    )
