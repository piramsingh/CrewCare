# WhatsApp Cloud API integration — StationShield

Menu-driven WhatsApp chatbot integrated with the `admin_dashboard_model`
Streamlit dashboard via a shared SQLite database. See the top-level
integration report (from the assistant, in-chat) for full context; this
file covers just how to run and extend the code.

## Files

| File | Purpose |
|---|---|
| `models.py` | SQLAlchemy models: linking, conversation state, `Employee`, `IssueReport` |
| `employee_service.py` | Employee lookup, demo seeding (EMP001/ADMIN001), login |
| `reports_service.py` | Create/query issue reports — the shared table the dashboard reads |
| `recommendations_service.py` | Bridges to `admin_dashboard_model`'s risk/flood/thermal/indoor modules |
| `conversation_service.py` | The menu state machine (MENU → report / medical history / recommendations) |
| `whatsapp_client.py` | Sends messages via the Graph API; `MockWhatsAppClient` fallback |
| `linking_service.py` | One-time code linking, rate limiting, unlink |
| `webhook.py` | FastAPI router: webhook endpoints, linking endpoints, `/api/auth/login` |
| `db.py` | DB session — now resolves an absolute shared path, no edit needed |
| `auth.py` | **Still a placeholder** — demo-only header-based "auth", replace before anything beyond local testing |
| `ai_client.py` | Unused by the current flow (no more free-form AI branch) — kept in case you reintroduce one |
| `tests/test_integration.py` | Covers spec section 11: DB, conversation flow, linking |

## Running it

```bash
cd project
python3 -m venv venv && source venv/bin/activate
pip install -r whatsapp/requirements.txt

cp whatsapp/.env.example whatsapp/.env   # fill in ADMIN_DASHBOARD_PASSWORD at minimum

uvicorn main:app --reload --port 8000
```

In a second terminal, run the dashboard (from the repo root):

```bash
cd admin_dashboard_model
ADMIN_DASHBOARD_PASSWORD=changeme streamlit run app.py
```

Both processes now read/write the same file:
`<repo root>/project/stationshield_whatsapp.db`.

## Testing

```bash
pip install pytest
pytest whatsapp/tests/ -v
```

Exercises the conversation flow, linking, and report storage directly
(no HTTP, no real WhatsApp calls). See the integration report for what
ran here vs. what you should verify locally.

## Testing the full loop via curl (mock WhatsApp client)

```bash
# 1. Link EMP001
curl -X POST http://localhost:8000/api/whatsapp/linking/start -H "X-Demo-Employee-Id: EMP001"
# -> {"code": "482913", ...}

curl -X POST http://localhost:8000/api/webhooks/whatsapp -H "Content-Type: application/json" -d '{
  "entry":[{"changes":[{"value":{"messages":[{"id":"wamid.1","from":"15551234567","text":{"body":"482913"}}]}}]}]}'

# 2. Walk the menu
curl -X POST http://localhost:8000/api/webhooks/whatsapp -H "Content-Type: application/json" -d '{
  "entry":[{"changes":[{"value":{"messages":[{"id":"wamid.2","from":"15551234567","text":{"body":"hi"}}]}}]}]}'
# change "body" to "1", then "4", "3", a description, "yes" ... watch the [MOCK WHATSAPP SEND] logs
```

Then open the dashboard and check the new "Worker-Reported Issues (WhatsApp)"
section — the report you just submitted should be there, anonymized.

## What's intentionally not done here

- **No frontend.** `/api/auth/login` exists; nothing calls it yet.
- **Medical history (option 2) is a single free-text field**, not a real
  medical schema — neither original codebase had one to extend, and
  inventing structured medical fields wasn't something I was willing to
  guess at. See the integration report.
- **Real WhatsApp Cloud API / ngrok setup** is unchanged from before —
  still needs your Meta credentials; the mock client covers local testing.
- **No async task queue** — `recommendations_service.py` calls Open-Meteo
  synchronously inside the webhook handler, which is fine for a demo but
  would need queuing under real load (per the original spec's own warning
  about not doing heavy work synchronously in a webhook).
- **`auth.py` is still a demo placeholder.**
