"""
Database models for the WhatsApp integration.

These are intentionally minimal and additive: they assume a `WorkerAccount`
table already exists elsewhere in the app (from the auth/worker module) and
only reference it by `employee_id`. Wire the ForeignKey up to your real
User/WorkerProfile table when integrating.
"""
from datetime import datetime, timedelta
import enum
import secrets

from sqlalchemy import (
    Column,
    Integer,
    String,
    Boolean,
    DateTime,
    Enum as SAEnum,
    ForeignKey,
    UniqueConstraint,
)
from sqlalchemy.orm import declarative_base

Base = declarative_base()

LINKING_CODE_TTL_MINUTES = 10
LINKING_CODE_LENGTH = 6


class ConversationState(str, enum.Enum):
    START = "START"
    MENU = "MENU"
    # Report-an-issue sub-flow (menu option 1)
    REPORT_CATEGORY = "REPORT_CATEGORY"
    REPORT_SEVERITY = "REPORT_SEVERITY"
    REPORT_DESCRIPTION = "REPORT_DESCRIPTION"
    REPORT_STATION = "REPORT_STATION"
    REPORT_CONFIRM = "REPORT_CONFIRM"
    # Medical history sub-flow (menu option 2) — extension point, see
    # employee_service.py / conversation_service.py docstrings.
    MEDICAL_HISTORY_MENU = "MEDICAL_HISTORY_MENU"
    MEDICAL_HISTORY_INPUT = "MEDICAL_HISTORY_INPUT"
    COMPLETED = "COMPLETED"

    # --- Legacy states from the original consent-first build. Kept so old
    # rows / any code still referencing them doesn't break, but the current
    # conversation_service.py no longer routes into these. ---
    CONSENT = "CONSENT"
    BASIC_HEALTH = "BASIC_HEALTH"
    REPORT_OPTION = "REPORT_OPTION"
    REPORT_UPLOAD = "REPORT_UPLOAD"
    HEALTH_APP_OPTION = "HEALTH_APP_OPTION"
    ENVIRONMENTAL_SUMMARY = "ENVIRONMENTAL_SUMMARY"
    RECOMMENDATIONS = "RECOMMENDATIONS"
    CONCERN_REVIEW = "CONCERN_REVIEW"
    FREEFORM_QA = "FREEFORM_QA"


ISSUE_CATEGORIES: dict[str, str] = {
    "1": "Air quality",
    "2": "Heat or temperature",
    "3": "Flooding or water",
    "4": "Mold or dampness",
    "5": "Other",
}

SEVERITY_LEVELS: dict[str, str] = {
    "1": "Low",
    "2": "Medium",
    "3": "High",
    "4": "Emergency",
}

REPORT_STATUSES = ("submitted", "under_review", "resolved")


class LinkingCode(Base):
    """A short-lived, single-use code a worker sends over WhatsApp to prove
    they control both the logged-in web session and the WhatsApp number."""

    __tablename__ = "linking_codes"

    id = Column(Integer, primary_key=True)
    employee_id = Column(String, nullable=False, index=True)
    code = Column(String, nullable=False, unique=True, index=True)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    expires_at = Column(DateTime, nullable=False)
    used_at = Column(DateTime, nullable=True)
    attempt_count = Column(Integer, default=0, nullable=False)

    @classmethod
    def generate(cls, employee_id: str) -> "LinkingCode":
        # Numeric code -> easy to type on a phone keyboard.
        code = f"{secrets.randbelow(10**LINKING_CODE_LENGTH):0{LINKING_CODE_LENGTH}d}"
        return cls(
            employee_id=employee_id,
            code=code,
            expires_at=datetime.utcnow() + timedelta(minutes=LINKING_CODE_TTL_MINUTES),
        )

    @property
    def is_expired(self) -> bool:
        return datetime.utcnow() > self.expires_at

    @property
    def is_used(self) -> bool:
        return self.used_at is not None


class WhatsAppLink(Base):
    """A confirmed link between a WhatsApp number and an employee account."""

    __tablename__ = "whatsapp_links"
    __table_args__ = (UniqueConstraint("whatsapp_number", name="uq_whatsapp_number"),)

    id = Column(Integer, primary_key=True)
    employee_id = Column(String, nullable=False, index=True)
    # Store the normalized WhatsApp/E.164 number. Never log this value elsewhere.
    whatsapp_number = Column(String, nullable=False, index=True)
    linked_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    revoked_at = Column(DateTime, nullable=True)

    @property
    def is_active(self) -> bool:
        return self.revoked_at is None


class ConversationSession(Base):
    """Persisted per-worker conversation state so the flow can resume across
    separate incoming WhatsApp messages/webhook calls."""

    __tablename__ = "conversation_sessions"

    id = Column(Integer, primary_key=True)
    employee_id = Column(String, nullable=False, unique=True, index=True)
    state = Column(SAEnum(ConversationState), default=ConversationState.START, nullable=False)
    consent_given = Column(Boolean, default=False, nullable=False)
    health_sharing_opt_in = Column(Boolean, default=False, nullable=False)
    # JSON-encoded scratch space for a multi-step flow in progress, e.g. the
    # issue report being built up across several incoming messages:
    # {"category": "...", "severity": "...", "description": "...", "station_id": "..."}
    pending_data = Column(String, nullable=True)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)


class Employee(Base):
    """Minimal employee record. Neither existing codebase had one — this is
    new. Role is a plain string ("worker" / "admin") rather than an enum so
    it's trivial to extend without a migration."""

    __tablename__ = "employees"

    id = Column(Integer, primary_key=True)
    employee_id = Column(String, nullable=False, unique=True, index=True)
    role = Column(String, nullable=False, default="worker")  # "worker" | "admin"
    station_id = Column(String, nullable=True)  # gtfs_stop_id, matches the station spine CSV
    station_name = Column(String, nullable=True)
    # Extension point for option 2 (medical history). Deliberately just a
    # single free-text field with no structured medical fields invented —
    # see conversation_service.py's MEDICAL_HISTORY_* handling and the final
    # report's "Important limitations" section for what remains incomplete.
    medical_notes = Column(String, nullable=True)
    medical_notes_updated_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)


class IssueReport(Base):
    """A worker-submitted environmental/safety issue report.

    Full detail (employee_id, exact created_at) is kept here for the
    worker-facing workflow: their own report history, duplicate-submission
    checks, and admin status tracking. The *admin dashboard* deliberately
    reads this table through admin_dashboard_model/whatsapp_reports.py,
    which drops employee_id and truncates created_at to a date before
    display — matching complaints.py's existing anonymization design rather
    than the raw fields here. See that module for why.
    """

    __tablename__ = "issue_reports"

    id = Column(Integer, primary_key=True)
    report_code = Column(String, nullable=False, unique=True, index=True)  # e.g. "ISSUE-4821"
    employee_id = Column(String, nullable=False, index=True)
    station_id = Column(String, nullable=True, index=True)
    station_name = Column(String, nullable=True)
    category = Column(String, nullable=False)
    severity = Column(String, nullable=False)
    description = Column(String, nullable=False)
    status = Column(String, nullable=False, default="submitted")
    source = Column(String, nullable=False, default="whatsapp")  # "whatsapp" | "dashboard"
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)


class ProcessedWebhookEvent(Base):
    """De-duplication record: Meta may redeliver the same webhook event on
    timeout/retry. Track message ids we've already handled."""

    __tablename__ = "processed_webhook_events"

    id = Column(Integer, primary_key=True)
    whatsapp_message_id = Column(String, nullable=False, unique=True, index=True)
    processed_at = Column(DateTime, default=datetime.utcnow, nullable=False)
