"""
Shared issue-report storage: one table (`issue_reports`), one service, used
by the WhatsApp conversation flow to write and by the admin dashboard to
read (via admin_dashboard_model/whatsapp_reports.py, which anonymizes on
the way out — see that module).

This does NOT touch complaints.py's existing anonymous complaint store.
That system stays exactly as it was; this is a second, separate, identity-
linked report table for the new WhatsApp-driven flow, as section 6 of the
integration spec asks for.
"""
from __future__ import annotations

import random
from datetime import datetime, timedelta

from sqlalchemy.orm import Session

from .models import IssueReport

DUPLICATE_WINDOW_MINUTES = 5


def _generate_report_code(db: Session) -> str:
    for _ in range(20):
        candidate = f"ISSUE-{random.randint(1000, 9999)}"
        if db.query(IssueReport).filter_by(report_code=candidate).one_or_none() is None:
            return candidate
    # Astronomically unlikely fallback.
    return f"ISSUE-{int(datetime.utcnow().timestamp())}"


def recent_duplicate(db: Session, employee_id: str, category: str, description: str) -> IssueReport | None:
    """Best-effort duplicate guard: same employee, same category and text,
    submitted in the last few minutes (e.g. a retried webhook or a worker
    double-tapping confirm)."""
    cutoff = datetime.utcnow() - timedelta(minutes=DUPLICATE_WINDOW_MINUTES)
    return (
        db.query(IssueReport)
        .filter(
            IssueReport.employee_id == employee_id,
            IssueReport.category == category,
            IssueReport.description == description,
            IssueReport.created_at >= cutoff,
        )
        .order_by(IssueReport.created_at.desc())
        .first()
    )


def create_report(
    db: Session,
    employee_id: str,
    category: str,
    severity: str,
    description: str,
    station_id: str | None = None,
    station_name: str | None = None,
    source: str = "whatsapp",
) -> IssueReport:
    duplicate = recent_duplicate(db, employee_id, category, description)
    if duplicate is not None:
        return duplicate  # Don't create a second row; caller still gets a valid report back.

    report = IssueReport(
        report_code=_generate_report_code(db),
        employee_id=employee_id,
        station_id=station_id,
        station_name=station_name,
        category=category,
        severity=severity,
        description=description,
        status="submitted",
        source=source,
    )
    db.add(report)
    db.commit()
    db.refresh(report)
    return report


def get_reports_for_station(db: Session, station_id: str) -> list[IssueReport]:
    return (
        db.query(IssueReport)
        .filter_by(station_id=station_id)
        .order_by(IssueReport.created_at.desc())
        .all()
    )


def get_reports_for_employee(db: Session, employee_id: str) -> list[IssueReport]:
    return (
        db.query(IssueReport)
        .filter_by(employee_id=employee_id)
        .order_by(IssueReport.created_at.desc())
        .all()
    )


def update_status(db: Session, report_code: str, status: str) -> IssueReport | None:
    report = db.query(IssueReport).filter_by(report_code=report_code).one_or_none()
    if report is None:
        return None
    report.status = status
    db.add(report)
    db.commit()
    db.refresh(report)
    return report
