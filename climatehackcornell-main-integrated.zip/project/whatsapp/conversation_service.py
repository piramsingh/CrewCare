"""
Menu-driven WhatsApp conversation flow:

    Hi/Hello/START -> MENU
        1 -> report an issue      (REPORT_CATEGORY -> ...SEVERITY -> ...DESCRIPTION
                                    -> ...STATION -> ...CONFIRM -> COMPLETED)
        2 -> medical history      (MEDICAL_HISTORY_MENU -> ...INPUT -> COMPLETED)
        3 -> today's recommendations (COMPLETED)

Replaces the earlier consent-first flow (see models.py's "Legacy states"
comment for what those states were). Deterministic and scripted throughout --
no AI-generated text in the safety-relevant report/medical branches; only
option 3's environmental numbers vary, and those come from the model, not
an LLM.
"""
from __future__ import annotations

import json

from sqlalchemy.orm import Session

from .models import (
    ConversationSession,
    ConversationState,
    ISSUE_CATEGORIES,
    SEVERITY_LEVELS,
)
from . import employee_service, reports_service
from .recommendations_service import (
    get_station_recommendation,
    format_recommendation_message,
    format_unavailable_message,
    RecommendationUnavailable,
)

MENU_TEXT = (
    "Hi! Welcome to StationShield.\n\n"
    "Please choose an option:\n\n"
    "1. Report an issue\n"
    "2. Change my medical history\n"
    "3. Get recommendations for today\n\n"
    "Reply with 1, 2, or 3."
)

CATEGORY_PROMPT = (
    "What type of issue are you reporting?\n\n"
    "1. Air quality\n"
    "2. Heat or temperature\n"
    "3. Flooding or water\n"
    "4. Mold or dampness\n"
    "5. Other"
)

SEVERITY_PROMPT = (
    "How severe is the issue?\n\n"
    "1. Low\n2. Medium\n3. High\n4. Emergency"
)

_OPTION_1_SYNONYMS = {"1", "report", "report an issue", "issue"}
_OPTION_2_SYNONYMS = {"2", "medical history", "update health", "change my medical history"}
_OPTION_3_SYNONYMS = {"3", "recommendations", "today's recommendations", "recommendations for today"}


def _get_or_create_session(db: Session, employee_id: str) -> ConversationSession:
    session = db.query(ConversationSession).filter_by(employee_id=employee_id).one_or_none()
    if session is None:
        session = ConversationSession(employee_id=employee_id, state=ConversationState.START)
        db.add(session)
        db.commit()
        db.refresh(session)
    return session


def _load_pending(session: ConversationSession) -> dict:
    if not session.pending_data:
        return {}
    try:
        return json.loads(session.pending_data)
    except ValueError:
        return {}


def _save_pending(session: ConversationSession, data: dict) -> None:
    session.pending_data = json.dumps(data)


def handle_incoming_message(db: Session, employee_id: str, message_text: str) -> str:
    session = _get_or_create_session(db, employee_id)
    text = (message_text or "").strip()
    lower = text.lower()

    if lower in ("stop", "exit", "cancel"):
        session.state = ConversationState.COMPLETED
        session.pending_data = None
        db.add(session)
        db.commit()
        return "Okay, ending this session. Message START or MENU anytime to begin again."

    if lower == "menu":
        session.state = ConversationState.MENU
        session.pending_data = None
        db.add(session)
        db.commit()
        return MENU_TEXT

    state = session.state

    if state in (ConversationState.START, ConversationState.COMPLETED) or lower in ("hi", "hello", "start"):
        session.state = ConversationState.MENU
        reply = MENU_TEXT

    elif state == ConversationState.MENU:
        reply = _handle_menu_choice(db, session, employee_id, lower)

    elif state == ConversationState.REPORT_CATEGORY:
        reply = _handle_report_category(session, text)

    elif state == ConversationState.REPORT_SEVERITY:
        reply = _handle_report_severity(session, text)

    elif state == ConversationState.REPORT_DESCRIPTION:
        reply = _handle_report_description(db, session, employee_id, text)

    elif state == ConversationState.REPORT_STATION:
        reply = _handle_report_station(session, text)

    elif state == ConversationState.REPORT_CONFIRM:
        reply = _handle_report_confirm(db, session, employee_id, lower)

    elif state == ConversationState.MEDICAL_HISTORY_MENU:
        reply = _handle_medical_history_menu(db, session, employee_id, lower)

    elif state == ConversationState.MEDICAL_HISTORY_INPUT:
        reply = _handle_medical_history_input(db, session, employee_id, text)

    else:
        # Any legacy/unrecognized state -- reset cleanly rather than getting stuck.
        session.state = ConversationState.MENU
        session.pending_data = None
        reply = MENU_TEXT

    db.add(session)
    db.commit()
    return reply


# --- Menu dispatch ---------------------------------------------------------


def _handle_menu_choice(db: Session, session: ConversationSession, employee_id: str, lower: str) -> str:
    if lower in _OPTION_1_SYNONYMS:
        session.state = ConversationState.REPORT_CATEGORY
        _save_pending(session, {})
        return CATEGORY_PROMPT

    if lower in _OPTION_2_SYNONYMS:
        session.state = ConversationState.MEDICAL_HISTORY_MENU
        return (
            "You can update the optional medical/health notes on your account. This is "
            "voluntary, visible only to authorized reviewers (never shown to your "
            "administrator by default), and used only to support a review if you request one "
            "-- never to make an automated fitness decision.\n\n"
            "Reply UPDATE to enter new notes, VIEW to see what's currently on file, or SKIP."
        )

    if lower in _OPTION_3_SYNONYMS:
        return _handle_recommendations(db, employee_id)

    return "Sorry, I didn't catch that. " + MENU_TEXT


# --- Option 1: report an issue ---------------------------------------------


def _handle_report_category(session: ConversationSession, text: str) -> str:
    choice = text.strip()
    category = ISSUE_CATEGORIES.get(choice)
    if category is None:
        for label in ISSUE_CATEGORIES.values():
            if text.strip().lower() == label.lower():
                category = label
                break
    if category is None:
        return "Please reply with a number 1-5.\n\n" + CATEGORY_PROMPT

    pending = _load_pending(session)
    pending["category"] = category
    _save_pending(session, pending)
    session.state = ConversationState.REPORT_SEVERITY
    return SEVERITY_PROMPT


def _handle_report_severity(session: ConversationSession, text: str) -> str:
    choice = text.strip()
    severity = SEVERITY_LEVELS.get(choice)
    if severity is None:
        for label in SEVERITY_LEVELS.values():
            if text.strip().lower() == label.lower():
                severity = label
                break
    if severity is None:
        return "Please reply with a number 1-4.\n\n" + SEVERITY_PROMPT

    pending = _load_pending(session)
    pending["severity"] = severity
    _save_pending(session, pending)
    session.state = ConversationState.REPORT_DESCRIPTION
    return "Please describe the issue in your own words."


def _handle_report_description(db: Session, session: ConversationSession, employee_id: str, text: str) -> str:
    if not text.strip():
        return "Please describe the issue in a few words."

    pending = _load_pending(session)
    pending["description"] = text.strip()
    _save_pending(session, pending)

    employee = employee_service.get_or_create_employee(db, employee_id)
    if employee.station_id:
        pending["station_id"] = employee.station_id
        pending["station_name"] = employee.station_name
        _save_pending(session, pending)
        session.state = ConversationState.REPORT_CONFIRM
        return _confirmation_text(pending)

    session.state = ConversationState.REPORT_STATION
    return "Which station is this for? Reply with the station name or ID."


def _handle_report_station(session: ConversationSession, text: str) -> str:
    if not text.strip():
        return "Please provide the station name or ID."
    pending = _load_pending(session)
    pending["station_id"] = None
    pending["station_name"] = text.strip()
    _save_pending(session, pending)
    session.state = ConversationState.REPORT_CONFIRM
    return _confirmation_text(pending)


def _confirmation_text(pending: dict) -> str:
    station = pending.get("station_name") or "unspecified"
    return (
        "Please confirm your report:\n\n"
        f"Station: {station}\n"
        f"Category: {pending.get('category')}\n"
        f"Severity: {pending.get('severity')}\n"
        f"Description: {pending.get('description')}\n\n"
        "Reply YES to submit or NO to cancel."
    )


def _handle_report_confirm(db: Session, session: ConversationSession, employee_id: str, lower: str) -> str:
    if lower not in ("yes", "no"):
        pending = _load_pending(session)
        return "Please reply YES to submit or NO to cancel.\n\n" + _confirmation_text(pending)

    pending = _load_pending(session)
    session.pending_data = None
    session.state = ConversationState.COMPLETED

    if lower == "no":
        return "Report cancelled. Reply MENU for options."

    try:
        report = reports_service.create_report(
            db,
            employee_id=employee_id,
            category=pending.get("category", "Other"),
            severity=pending.get("severity", "Low"),
            description=pending.get("description", ""),
            station_id=pending.get("station_id"),
            station_name=pending.get("station_name"),
            source="whatsapp",
        )
    except Exception:
        return (
            "Sorry -- something went wrong saving your report and it was NOT submitted. "
            "Please try again, or contact your supervisor directly if this is urgent."
        )

    return (
        "Your report has been submitted successfully.\n\n"
        f"Your report ID is: {report.report_code}\n\n"
        "Thank you for helping improve worker safety.\n\nReply MENU for options."
    )


# --- Option 2: medical history (extension point) ----------------------------


def _handle_medical_history_menu(db: Session, session: ConversationSession, employee_id: str, lower: str) -> str:
    if lower == "update":
        session.state = ConversationState.MEDICAL_HISTORY_INPUT
        return "Please enter the notes you'd like on file. Reply SKIP to leave this unchanged."

    if lower == "view":
        session.state = ConversationState.COMPLETED
        employee = employee_service.get_or_create_employee(db, employee_id)
        if employee.medical_notes:
            return f"Currently on file: \"{employee.medical_notes}\"\n\nReply MENU for options."
        return "Nothing is currently on file.\n\nReply MENU for options."

    session.state = ConversationState.COMPLETED
    return "No changes made. Reply MENU for options."


def _handle_medical_history_input(db: Session, session: ConversationSession, employee_id: str, text: str) -> str:
    session.state = ConversationState.COMPLETED
    if text.strip().lower() == "skip":
        return "No changes made. Reply MENU for options."

    from datetime import datetime

    employee = employee_service.get_or_create_employee(db, employee_id)
    employee.medical_notes = text.strip()
    employee.medical_notes_updated_at = datetime.utcnow()
    db.add(employee)
    db.commit()

    return (
        "Your notes have been updated. This information is voluntary, stored securely, "
        "and is not shown to your administrator by default.\n\nReply MENU for options."
    )


# --- Option 3: recommendations ----------------------------------------------


def _handle_recommendations(db: Session, employee_id: str) -> str:
    employee = employee_service.get_or_create_employee(db, employee_id)
    if not employee.station_id:
        return (
            "You don't have an assigned station on file, so a station-specific summary "
            "isn't available. Contact your supervisor to confirm your station assignment.\n\n"
            "Reply MENU for options."
        )
    try:
        rec = get_station_recommendation(employee.station_id)
        return format_recommendation_message(rec)
    except RecommendationUnavailable:
        return format_unavailable_message(employee.station_name)
