"""
Employee lookup and seeding.

Neither the WhatsApp backend nor the Streamlit dashboard had any employee,
role, or station-assignment model before this integration. This module adds
the minimum needed to satisfy the login/routing flow in the spec:

    employee enters ID -> role lookup -> admin dashboard | worker chatbot

There is still no web frontend anywhere in this repo (see main.py and the
final integration report for what that means in practice) — the FastAPI
`/api/auth/login` endpoint this module backs is ready for one to call, but
nothing currently calls it except tests/curl.
"""
from __future__ import annotations

from sqlalchemy.orm import Session

from .models import Employee

DEMO_EMPLOYEES = (
    # employee_id, role, station_id (gtfs_stop_id), station_name
    ("EMP001", "worker", "A02", "Inwood-207 St"),
    ("ADMIN001", "admin", None, None),
)


def seed_demo_employees(db: Session) -> int:
    """Idempotent: only inserts employee_ids that don't already exist."""
    created = 0
    for employee_id, role, station_id, station_name in DEMO_EMPLOYEES:
        exists = db.query(Employee).filter_by(employee_id=employee_id).one_or_none()
        if exists is not None:
            continue
        db.add(Employee(
            employee_id=employee_id,
            role=role,
            station_id=station_id,
            station_name=station_name,
        ))
        created += 1
    if created:
        db.commit()
    return created


def get_employee(db: Session, employee_id: str) -> Employee | None:
    return db.query(Employee).filter_by(employee_id=employee_id).one_or_none()


def get_or_create_employee(db: Session, employee_id: str, role: str = "worker") -> Employee:
    """Used by the webhook when a linked WhatsApp number maps to an
    employee_id that isn't in the Employee table yet (e.g. linked before
    this table existed). Defaults new employees to 'worker'."""
    employee = get_employee(db, employee_id)
    if employee is not None:
        return employee
    employee = Employee(employee_id=employee_id, role=role)
    db.add(employee)
    db.commit()
    db.refresh(employee)
    return employee


class LoginError(Exception):
    pass


def login(db: Session, employee_id: str) -> Employee:
    """Demo-only 'authentication': looks up the employee_id and returns their
    record. No password — matches the spec's 'demo authentication' framing.
    Replace with real credential verification before this is anything but a
    hackathon demo."""
    employee = get_employee(db, employee_id)
    if employee is None:
        raise LoginError(f"No employee found for ID '{employee_id}'.")
    return employee
