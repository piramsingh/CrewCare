"""
Covers the testing requirements from section 11 of the integration spec:
database, conversation flow, employee linking, and report retrieval.

Run with (from project/):
    pip install -r whatsapp/requirements.txt pytest
    pytest whatsapp/tests/ -v

Does NOT hit the real WhatsApp API or make any network calls — conversation
logic is exercised directly through conversation_service.handle_incoming_message,
and linking through linking_service, bypassing the webhook/HTTP layer.
"""
from __future__ import annotations

import pytest
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from whatsapp.models import Base, IssueReport, WhatsAppLink
from whatsapp import employee_service, linking_service, reports_service, conversation_service


@pytest.fixture()
def db():
    engine = create_engine("sqlite:///:memory:", connect_args={"check_same_thread": False})
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine)
    session = Session()
    employee_service.seed_demo_employees(session)
    yield session
    session.close()


# --- Database ---------------------------------------------------------------


def test_database_initializes(db):
    assert employee_service.get_employee(db, "EMP001") is not None
    assert employee_service.get_employee(db, "ADMIN001") is not None


def test_issue_report_create_and_retrieve_by_station(db):
    report = reports_service.create_report(
        db, employee_id="EMP001", category="Heat or temperature", severity="Medium",
        description="Very hot on the platform", station_id="A02", station_name="Inwood-207 St",
    )
    assert report.report_code.startswith("ISSUE-")

    by_station = reports_service.get_reports_for_station(db, "A02")
    assert len(by_station) == 1
    assert by_station[0].report_code == report.report_code


def test_existing_records_preserved_across_new_writes(db):
    reports_service.create_report(
        db, "EMP001", "Heat or temperature", "Low", "First report", station_id="A02",
    )
    reports_service.create_report(
        db, "EMP001", "Air quality", "Low", "Second, different report", station_id="A02",
    )
    assert db.query(IssueReport).count() == 2


def test_duplicate_submission_within_window_does_not_double_insert(db):
    reports_service.create_report(db, "EMP001", "Heat or temperature", "Low", "Same text", station_id="A02")
    reports_service.create_report(db, "EMP001", "Heat or temperature", "Low", "Same text", station_id="A02")
    assert db.query(IssueReport).count() == 1


# --- Conversation flow --------------------------------------------------------


def _link(db, employee_id="EMP001", number="15551234567"):
    code = linking_service.start_linking(db, employee_id)
    linking_service.verify_and_link(db, code.code, number)
    return number


def test_hi_shows_menu(db):
    reply = conversation_service.handle_incoming_message(db, "EMP001", "Hi")
    assert "1. Report an issue" in reply
    assert "2. Change my medical history" in reply
    assert "3. Get recommendations for today" in reply


def test_option_1_starts_issue_flow_and_stores_category(db):
    conversation_service.handle_incoming_message(db, "EMP001", "Hi")
    reply = conversation_service.handle_incoming_message(db, "EMP001", "1")
    assert "What type of issue" in reply

    reply = conversation_service.handle_incoming_message(db, "EMP001", "2")  # Heat
    assert "How severe" in reply


def test_full_report_flow_confirm_yes_saves_report(db):
    conversation_service.handle_incoming_message(db, "EMP001", "Hi")
    conversation_service.handle_incoming_message(db, "EMP001", "1")        # report
    conversation_service.handle_incoming_message(db, "EMP001", "4")        # mold/dampness
    conversation_service.handle_incoming_message(db, "EMP001", "3")        # high severity
    reply = conversation_service.handle_incoming_message(db, "EMP001", "Damp smell near the stairs")
    assert "Please confirm your report" in reply
    assert "Mold or dampness" in reply
    assert "High" in reply

    reply = conversation_service.handle_incoming_message(db, "EMP001", "YES")
    assert "submitted successfully" in reply
    assert "ISSUE-" in reply

    reports = reports_service.get_reports_for_employee(db, "EMP001")
    assert len(reports) == 1
    assert reports[0].category == "Mold or dampness"
    assert reports[0].station_id == "A02"  # from EMP001's seeded assignment


def test_no_cancels_report(db):
    conversation_service.handle_incoming_message(db, "EMP001", "Hi")
    conversation_service.handle_incoming_message(db, "EMP001", "1")
    conversation_service.handle_incoming_message(db, "EMP001", "1")
    conversation_service.handle_incoming_message(db, "EMP001", "1")
    conversation_service.handle_incoming_message(db, "EMP001", "Loud noise near the tracks")
    reply = conversation_service.handle_incoming_message(db, "EMP001", "NO")
    assert "cancelled" in reply.lower()
    assert reports_service.get_reports_for_employee(db, "EMP001") == []


def test_conversation_state_resets_after_submission(db):
    conversation_service.handle_incoming_message(db, "EMP001", "Hi")
    conversation_service.handle_incoming_message(db, "EMP001", "1")
    conversation_service.handle_incoming_message(db, "EMP001", "1")
    conversation_service.handle_incoming_message(db, "EMP001", "1")
    conversation_service.handle_incoming_message(db, "EMP001", "Something")
    conversation_service.handle_incoming_message(db, "EMP001", "YES")

    # Next message should show the menu again, not continue the old flow.
    reply = conversation_service.handle_incoming_message(db, "EMP001", "Hi")
    assert "Please choose an option" in reply


def test_medical_history_skip_makes_no_change(db):
    conversation_service.handle_incoming_message(db, "EMP001", "Hi")
    conversation_service.handle_incoming_message(db, "EMP001", "2")
    reply = conversation_service.handle_incoming_message(db, "EMP001", "skip")
    assert "No changes made" in reply
    employee = employee_service.get_employee(db, "EMP001")
    assert employee.medical_notes is None


def test_medical_history_update_then_view(db):
    conversation_service.handle_incoming_message(db, "EMP001", "Hi")
    conversation_service.handle_incoming_message(db, "EMP001", "2")
    conversation_service.handle_incoming_message(db, "EMP001", "update")
    conversation_service.handle_incoming_message(db, "EMP001", "Mild dust sensitivity")

    conversation_service.handle_incoming_message(db, "EMP001", "Hi")
    conversation_service.handle_incoming_message(db, "EMP001", "2")
    reply = conversation_service.handle_incoming_message(db, "EMP001", "view")
    assert "Mild dust sensitivity" in reply


# --- Employee linking --------------------------------------------------------


def test_first_time_linking_works(db):
    number = _link(db)
    assert linking_service.resolve_employee_id(db, number) == "EMP001"


def test_returning_worker_recognized_as_already_linked(db):
    number = _link(db)
    # Simulate a second, unrelated message from the same number later.
    assert linking_service.resolve_employee_id(db, number) == "EMP001"


def test_linked_number_cannot_be_reassigned_to_another_employee(db):
    number = _link(db, "EMP001", "15551234567")
    code2 = linking_service.start_linking(db, "ADMIN001")
    with pytest.raises(linking_service.LinkingError):
        linking_service.verify_and_link(db, code2.code, number)

    link = db.query(WhatsAppLink).filter_by(whatsapp_number=number).one()
    assert link.employee_id == "EMP001"


def test_expired_code_is_rejected(db):
    code = linking_service.start_linking(db, "EMP001")
    code.expires_at = code.created_at  # force expiry
    db.add(code)
    db.commit()
    with pytest.raises(linking_service.LinkingError, match="expired"):
        linking_service.verify_and_link(db, code.code, "15559998888")


def test_used_code_cannot_be_reused(db):
    number = "15551234567"
    code = linking_service.start_linking(db, "EMP001")
    linking_service.verify_and_link(db, code.code, number)
    with pytest.raises(linking_service.LinkingError, match="already been used"):
        linking_service.verify_and_link(db, code.code, "15550000000")
