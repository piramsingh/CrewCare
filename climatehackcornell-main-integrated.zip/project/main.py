from dotenv import load_dotenv

load_dotenv("whatsapp/.env")

from fastapi import FastAPI

from whatsapp.webhook import router as whatsapp_router
from whatsapp.db import SessionLocal
from whatsapp import employee_service

app = FastAPI(title="StationShield")

app.include_router(whatsapp_router)


@app.on_event("startup")
def _seed_demo_data() -> None:
    db = SessionLocal()
    try:
        created = employee_service.seed_demo_employees(db)
        if created:
            print(f"[startup] seeded {created} demo employee(s): EMP001 (worker), ADMIN001 (admin)")
    finally:
        db.close()


@app.get("/")
def health():
    return {"status": "ok"}
